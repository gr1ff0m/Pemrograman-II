package soal1;

public abstract class Shape {
    protected String shapeName;

    // Constructor
    public Shape(String name) {
        this.shapeName = name;
    }

    // Abstract method for calculating area
    public abstract double calculateArea();

    // Returns the name of the shape
    @Override
    public String toString() {
        return "Shape type: " + shapeName;
    }
}
