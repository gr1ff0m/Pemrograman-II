package soal1;

public class Rectangle extends Shape {
    private double length; // Length of the rectangle
    private double width;  // Width of the rectangle

    // Constructor
    public Rectangle(double length, double width) {
        super("Rectangle");
        this.length = length;
        this.width = width;
    }

    // Calculates the area of the rectangle
    @Override
    public double calculateArea() {
        return length * width;
    }

    // Returns the rectangle description as a string
    @Override
    public String toString() {
        return super.toString() + " with length " + length + " and width " + width;
    }
}
