package soal1;

public class Cylinder extends Shape {
    private double radius; // Radius of the base
    private double height; // Height of the cylinder

    // Constructor
    public Cylinder(double radius, double height) {
        super("Cylinder");
        this.radius = radius;
        this.height = height;
    }

    // Calculates the surface area of the cylinder
    @Override
    public double calculateArea() {
        return 2 * Math.PI * radius * (radius + height);
    }

    // Returns the cylinder description as a string
    @Override
    public String toString() {
        return super.toString() + " with radius " + radius + " and height " + height;
    }
}
