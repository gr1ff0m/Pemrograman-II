package soal1;

import java.text.DecimalFormat;

public class PaintThings {
    //-----------------------------------------
    // Creates some shapes and a Paint object
    // and prints the amount of paint needed
    // to paint each shape.
    //-----------------------------------------
    public static void main(String[] args) {
        final double COVERAGE = 350; // Cakupan cat dalam cm^2 per liter

        // Membuat objek Paint
        Paint paint = new Paint(COVERAGE);

        // Membuat objek bentuk: deck (persegi panjang), bigBall (bola), dan tank (silinder)
        Rectangle deck = new Rectangle(20, 30); // Panjang 20cm, Lebar 30cm
        Sphere bigBall = new Sphere(15);         // Radius 15cm
        Cylinder tank = new Cylinder(10, 30);    // Radius 10cm, Tinggi 30cm

        // Menghitung jumlah cat yang diperlukan untuk setiap bentuk
        double deckAmt = paint.amount(deck);  // Menghitung cat untuk deck
        double ballAmt = paint.amount(bigBall); // Menghitung cat untuk bigBall
        double tankAmt = paint.amount(tank); // Menghitung cat untuk tank

        // Format output untuk mencetak jumlah cat yang dibutuhkan
        DecimalFormat fmt = new DecimalFormat("0.#");

        // Menampilkan hasil perhitungan jumlah cat
        System.out.println("\nNumber of liters of paint needed...");
        System.out.println("Deck: " + fmt.format(deckAmt) + " liters");
        System.out.println("Big Ball: " + fmt.format(ballAmt) + " liters");
        System.out.println("Tank: " + fmt.format(tankAmt) + " liters");
    }
}
